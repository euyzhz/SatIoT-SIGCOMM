#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge SatIoT TX/RX logs stored in .docx (plain text paragraphs), compute BER, and export CSVs.

Example:
  python sat_log_merge_word.py \
    --tx sim_transmit_5pkts_13dB.docx \
    --rx sim_reception_5pkts_13dB.docx \
    --outdir out \
    --n-dev 5
"""

import argparse
import csv
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Tuple, Dict
from collections import defaultdict

from docx import Document


TS_RE = re.compile(r"\[(\d{2}:\d{2}:\d{2}\.\d{3})\]")


def ts_to_ms(ts: str) -> int:
    """HH:MM:SS.mmm -> milliseconds since 00:00:00.000 (assumes no midnight wrap)."""
    h, m, s_ms = ts.split(":")
    s, ms = s_ms.split(".")
    return (int(h) * 3600 + int(m) * 60 + int(s)) * 1000 + int(ms)


def sanitize_hex(s: str) -> str:
    """Keep only hex chars, uppercase."""
    return re.sub(r"[^0-9A-Fa-f]", "", s).upper()


def classify_payload(payload_hex: str) -> Tuple[str, str]:
    """Return (frame_type, hdr6). hdr6 = first 6 hex chars (3 bytes)."""
    p = sanitize_hex(payload_hex)
    if len(p) < 6:
        return "UNK", p
    if p.startswith("EBF"):
        return "EBF", p[:6]
    if p.startswith("EBA"):
        return "EBA", p[:6]
    return "UNK", p[:6]


def bit_errors_hex(a_hex: str, b_hex: str) -> Tuple[int, int, int]:
    """
    Compare bits for the common prefix length (byte-aligned).
    Return (bit_errors, compared_bits, length_mismatch_bits).

    Note:
      - compared_bits uses min(len(a), len(b)) truncated to even hex length.
      - length_mismatch_bits reports abs(len(a)-len(b))*4 after sanitization.
    """
    a = sanitize_hex(a_hex)
    b = sanitize_hex(b_hex)
    n = min(len(a), len(b))
    n -= n % 2  # byte align
    a_cmp = a[:n]
    b_cmp = b[:n]
    if n == 0:
        return 0, 0, abs(len(a) - len(b)) * 4

    ab = bytes.fromhex(a_cmp)
    bb = bytes.fromhex(b_cmp)
    err = 0
    for x, y in zip(ab, bb):
        err += (x ^ y).bit_count()
    compared_bits = len(ab) * 8
    length_mismatch_bits = abs(len(a) - len(b)) * 4
    return err, compared_bits, length_mismatch_bits


@dataclass
class Frame:
    side: str                 # 'tx' or 'rx'
    time_str: Optional[str]   # 'HH:MM:SS.mmm' or None
    time_ms: Optional[int]    # ms since midnight or None
    payload_hex: str          # sanitized, uppercase
    frame_type: str           # 'EBF'/'EBA'/'UNK'
    hdr6: str                 # first 6 hex chars
    rssi: Optional[int] = None
    snr: Optional[int] = None
    crc: Optional[str] = None # 'PASS'/'FAIL'/None


def parse_docx_rx(path: Path) -> List[Frame]:
    """
    RX log parser with tolerance for split frame prefixes, e.g.:
      [ts1]收←◆
      EB
      [ts2]收←◆F4C0...
    which should be merged as EBF4C0...

    Also tolerates payload continuation across multiple paragraphs (no timestamps),
    and even timestamped continuation lines, until CRC appears.
    """
    doc = Document(str(path))
    frames: List[Frame] = []

    pending_ts: Optional[str] = None
    pending_ts_ms: Optional[int] = None
    pending_prefix_hex: str = ""  # buffer for split prefix/payload fragments before we can start a frame

    last_frame: Optional[Frame] = None  # most recently created frame

    def start_frame(ts_for_frame: Optional[str], payload_hex: str) -> Frame:
        nonlocal last_frame
        ts = ts_for_frame
        tms = ts_to_ms(ts) if ts else None
        p = sanitize_hex(payload_hex)
        ftype, hdr6 = classify_payload(p)
        f = Frame(
            side="rx",
            time_str=ts,
            time_ms=tms,
            payload_hex=p,
            frame_type=ftype,
            hdr6=hdr6,
        )
        frames.append(f)
        last_frame = f
        return f

    def try_promote_pending_to_frame():
        """If pending_prefix_hex already forms a valid frame start, create the frame."""
        nonlocal pending_ts, pending_ts_ms, pending_prefix_hex
        if pending_ts and len(pending_prefix_hex) >= 6:
            p = sanitize_hex(pending_prefix_hex)
            if p.startswith(("EBF", "EBA")):
                start_frame(pending_ts, p)
                pending_ts = None
                pending_ts_ms = None
                pending_prefix_hex = ""

    for p in doc.paragraphs:
        line = (p.text or "").strip()
        if not line:
            continue

        # Timestamp line?
        m = TS_RE.search(line)
        if m:
            ts = m.group(1)

            # Extract payload fragment on same line after '◆' if any
            after_hex = ""
            if "◆" in line:
                after_hex = sanitize_hex(line.split("◆", 1)[1].strip())

            # If it is a timestamp-only marker, set pending_ts and continue
            if not after_hex:
                pending_ts = ts
                pending_ts_ms = ts_to_ms(ts)
                continue

            # Case A: if we are in the middle of assembling a payload (no CRC yet) and
            # this fragment is NOT a new frame start, treat it as continuation.
            if last_frame is not None and last_frame.crc is None and not after_hex.startswith(("EBF", "EBA")):
                last_frame.payload_hex += after_hex
                last_frame.payload_hex = sanitize_hex(last_frame.payload_hex)
                last_frame.frame_type, last_frame.hdr6 = classify_payload(last_frame.payload_hex)
                continue

            # Case B: pending prefix exists (e.g., "EB"), try combine with this fragment
            if pending_prefix_hex:
                combined = sanitize_hex(pending_prefix_hex + after_hex)
                if combined.startswith(("EBF", "EBA")):
                    # Use the earlier pending_ts if available, otherwise current ts
                    ts_for_frame = pending_ts or ts
                    start_frame(ts_for_frame, combined)
                    pending_ts = None
                    pending_ts_ms = None
                    pending_prefix_hex = ""
                    continue
                # If still not recognizable, keep buffering (use current ts as pending_ts)
                pending_ts = ts
                pending_ts_ms = ts_to_ms(ts)
                pending_prefix_hex = combined
                try_promote_pending_to_frame()
                continue

            # Case C: fragment itself is a valid frame start
            if after_hex.startswith(("EBF", "EBA")):
                start_frame(ts, after_hex)
                pending_ts = None
                pending_ts_ms = None
                pending_prefix_hex = ""
                continue

            # Case D: fragment is hex but not starting with EBF/EBA (could be split head like "EB" or continuation)
            pending_ts = ts
            pending_ts_ms = ts_to_ms(ts)
            pending_prefix_hex += after_hex
            pending_prefix_hex = sanitize_hex(pending_prefix_hex)
            try_promote_pending_to_frame()
            continue

        # ---- Non-timestamp lines ----
        u = line.upper()

        # meta lines attached to the most recent frame
        if last_frame is not None and u.startswith("RSSI:"):
            nums = re.findall(r"-?\d+", line)
            if nums:
                last_frame.rssi = int(nums[0])
            continue
        if last_frame is not None and u.startswith("SNR:"):
            nums = re.findall(r"-?\d+", line)
            if nums:
                last_frame.snr = int(nums[0])
            continue
        if last_frame is not None and u.startswith("CRC:"):
            if "PASS" in u:
                last_frame.crc = "PASS"
            elif "FAIL" in u:
                last_frame.crc = "FAIL"
            else:
                last_frame.crc = line.split(":", 1)[1].strip()
            continue

        maybe_hex = sanitize_hex(line)
        if not maybe_hex:
            continue

        # If it's a clear new frame start, start it (prefer pending_ts if exists)
        if maybe_hex.startswith(("EBF", "EBA")):
            ts_for_frame = pending_ts
            start_frame(ts_for_frame, maybe_hex)
            pending_ts = None
            pending_ts_ms = None
            pending_prefix_hex = ""
            continue

        # Otherwise, it's a hex fragment: either continuation of current frame (before CRC),
        # or a split prefix we should buffer.
        if last_frame is not None and last_frame.crc is None:
            last_frame.payload_hex += maybe_hex
            last_frame.payload_hex = sanitize_hex(last_frame.payload_hex)
            last_frame.frame_type, last_frame.hdr6 = classify_payload(last_frame.payload_hex)
            continue

        # No open frame: buffer as possible prefix/payload head (works for "EB" cases)
        if pending_ts is not None:
            pending_prefix_hex += maybe_hex
            pending_prefix_hex = sanitize_hex(pending_prefix_hex)
            try_promote_pending_to_frame()
        # else: ignore as noise

    return frames


def parse_docx_tx(path: Path) -> List[Frame]:
    """
    TX parser with the same split-prefix tolerance for timestamped lines like:
      [ts]收←◆EB
      [ts2]收←◆F4C0...
    """
    doc = Document(str(path))
    frames: List[Frame] = []

    pending_ts: Optional[str] = None
    pending_ts_ms: Optional[int] = None
    pending_prefix_hex: str = ""

    def start_frame(ts_for_frame: Optional[str], payload_hex: str) -> Frame:
        ts = ts_for_frame
        tms = ts_to_ms(ts) if ts else None
        p = sanitize_hex(payload_hex)
        ftype, hdr6 = classify_payload(p)
        f = Frame("tx", ts, tms, p, ftype, hdr6)
        frames.append(f)
        return f

    def try_promote_pending_to_frame():
        nonlocal pending_ts, pending_ts_ms, pending_prefix_hex
        if pending_ts and len(pending_prefix_hex) >= 6:
            p = sanitize_hex(pending_prefix_hex)
            if p.startswith(("EBF", "EBA")):
                start_frame(pending_ts, p)
                pending_ts = None
                pending_ts_ms = None
                pending_prefix_hex = ""

    for p in doc.paragraphs:
        line = (p.text or "").strip()
        if not line:
            continue

        m = TS_RE.search(line)
        if m:
            ts = m.group(1)
            after_hex = ""
            if "◆" in line:
                after_hex = sanitize_hex(line.split("◆", 1)[1].strip())

            # timestamp-only
            if not after_hex:
                pending_ts = ts
                pending_ts_ms = ts_to_ms(ts)
                continue

            # if pending prefix exists, try combine
            if pending_prefix_hex:
                combined = sanitize_hex(pending_prefix_hex + after_hex)
                if combined.startswith(("EBF", "EBA")):
                    ts_for_frame = pending_ts or ts
                    start_frame(ts_for_frame, combined)
                    pending_ts = None
                    pending_ts_ms = None
                    pending_prefix_hex = ""
                    continue
                pending_ts = ts
                pending_ts_ms = ts_to_ms(ts)
                pending_prefix_hex = combined
                try_promote_pending_to_frame()
                continue

            # normal start
            if after_hex.startswith(("EBF", "EBA")):
                start_frame(ts, after_hex)
                pending_ts = None
                pending_ts_ms = None
                pending_prefix_hex = ""
                continue

            # fragment like "EB" or continuation head
            pending_ts = ts
            pending_ts_ms = ts_to_ms(ts)
            pending_prefix_hex += after_hex
            pending_prefix_hex = sanitize_hex(pending_prefix_hex)
            try_promote_pending_to_frame()
            continue

        # non-timestamp
        maybe_hex = sanitize_hex(line)
        if not maybe_hex:
            continue

        if maybe_hex.startswith(("EBF", "EBA")):
            # For TX: EBA lines without timestamp should remain time_str=None as before
            ftype, _ = classify_payload(maybe_hex)
            if ftype == "EBA":
                frames.append(Frame("tx", None, None, maybe_hex, "EBA", maybe_hex[:6]))
            else:
                start_frame(pending_ts, maybe_hex)
            pending_ts = None
            pending_ts_ms = None
            pending_prefix_hex = ""
            continue

        # buffer fragments if we have a pending timestamp context
        if pending_ts is not None:
            pending_prefix_hex += maybe_hex
            pending_prefix_hex = sanitize_hex(pending_prefix_hex)
            try_promote_pending_to_frame()

    return frames



def build_groups(frames: List[Frame]) -> List[Dict]:
    """
    Group by EBF boundaries:
      group = { group_id, ebf(Frame or None), ebas([Frame]) }
    """
    groups: List[Dict] = []
    cur: Optional[Dict] = None
    group_id = -1

    for f in frames:
        if f.frame_type == "EBF":
            group_id += 1
            cur = {"group_id": group_id, "ebf": f, "ebas": []}
            groups.append(cur)
        elif f.frame_type == "EBA":
            if cur is None:
                group_id += 1
                cur = {"group_id": group_id, "ebf": None, "ebas": []}
                groups.append(cur)
            cur["ebas"].append(f)
        else:
            continue
    return groups


def group_similarity(txg: Dict, rxg: Dict) -> Tuple[float, int]:
    """Return (ber, compared_bits) for EBF payloads."""
    txp = txg["ebf"].payload_hex if txg["ebf"] else ""
    rxp = rxg["ebf"].payload_hex if rxg["ebf"] else ""
    err, bits, _ = bit_errors_hex(txp, rxp)
    ber = err / bits if bits else float("inf")
    return ber, bits


def match_groups_robust(tx_groups: List[Dict], rx_groups: List[Dict]) -> Dict[int, Optional[int]]:
    """
    Two-stage:
      1) Exact match by ebf.hdr6
      2) Fallback: among remaining rx groups, choose the one with minimal EBF BER (tie: closer index)
    """
    rx_used = set()
    rx_by_hdr6 = defaultdict(list)
    for i, rg in enumerate(rx_groups):
        hdr6 = rg["ebf"].hdr6 if rg["ebf"] else "NONE"
        rx_by_hdr6[hdr6].append(i)

    matched: Dict[int, Optional[int]] = {}
    # stage 1
    for ti, tg in enumerate(tx_groups):
        hdr6 = tg["ebf"].hdr6 if tg["ebf"] else "NONE"
        cand = rx_by_hdr6.get(hdr6, [])
        ri = None
        for x in cand:
            if x not in rx_used:
                ri = x
                break
        matched[ti] = ri
        if ri is not None:
            rx_used.add(ri)

    # stage 2
    for ti, ri in matched.items():
        if ri is not None:
            continue
        best = None
        for rj, rg in enumerate(rx_groups):
            if rj in rx_used:
                continue
            ber, bits = group_similarity(tx_groups[ti], rg)
            if bits == 0:
                continue
            score = (ber, abs(rj - ti))
            if best is None or score < best[0]:
                best = (score, rj)
        if best is not None:
            matched[ti] = best[1]
            rx_used.add(best[1])

    return matched


def split_eba_fields(payload_hex: str, n_devices: int) -> Optional[List[Tuple[str, Optional[int], str]]]:
    """
    EBA frame assumed:
      header_3B = 6 hex
      blocks    = n_devices * 16 hex (each block 8B = 16 hex)
      sat_id    = 2 hex
    """
    p = sanitize_hex(payload_hex)
    need = 6 + n_devices * 16 + 2
    if len(p) < need:
        return None

    header = p[:6]
    body = p[6:-2]
    sat_id = p[-2:]
    blocks = [body[i * 16:(i + 1) * 16] for i in range(n_devices)]

    fields: List[Tuple[str, Optional[int], str]] = []
    fields.append(("header_3B", None, header))
    for i, b in enumerate(blocks, start=1):
        fields.append(("block_8B", i, b))
        fields.append(("dev_id+ack_4B", i, b[:8]))
        fields.append(("xor_id+xor_ack_4B", i, b[8:16]))
    fields.append(("sat_id_1B", None, sat_id))
    return fields


def match_eba_list(tx_ebas: List[Frame], rx_ebas: List[Frame]) -> List[Optional[int]]:
    """
    Greedy match:
      For each tx EBA in order, pick an unmatched rx EBA with same hdr6 (if possible),
      minimizing BER; tie-break: prefer CRC PASS, then earlier rx index.
    """
    used = set()
    mapping: List[Optional[int]] = [None] * len(tx_ebas)

    for i, txf in enumerate(tx_ebas):
        best = None
        for j, rxf in enumerate(rx_ebas):
            if j in used:
                continue
            if txf.hdr6 and rxf.hdr6 and (txf.hdr6 != rxf.hdr6):
                continue
            err, bits, _ = bit_errors_hex(txf.payload_hex, rxf.payload_hex)
            if bits == 0:
                continue
            ber = err / bits
            crc_penalty = 0 if (rxf.crc == "PASS") else 1
            score = (ber, crc_penalty, j)
            if best is None or score < best[0]:
                best = (score, j)
        if best is not None:
            j = best[1]
            used.add(j)
            mapping[i] = j

    return mapping


def write_csv(path: Path, rows: List[Dict], fieldnames: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tx", required=True, type=Path, help="TX docx log (e.g., sim_transmit_5pkts_13dB.docx)")
    ap.add_argument("--rx", required=True, type=Path, help="RX docx log (e.g., sim_reception_5pkts_13dB.docx)")
    ap.add_argument("--outdir", default=Path("."), type=Path)
    ap.add_argument("--n-dev", default=5, type=int, help="number of device blocks in one EBA frame")
    args = ap.parse_args()

    tx_frames = parse_docx_tx(args.tx)
    rx_frames = parse_docx_rx(args.rx)

    tx_groups = build_groups(tx_frames)
    rx_groups = build_groups(rx_frames)
    gmap = match_groups_robust(tx_groups, rx_groups)

    merged_rows: List[Dict] = []
    eba_rows: List[Dict] = []

    for txgi, tg in enumerate(tx_groups):
        rxgi = gmap.get(txgi)
        rg = rx_groups[rxgi] if (rxgi is not None and 0 <= rxgi < len(rx_groups)) else None

        tx_ebf = tg["ebf"]
        rx_ebf = rg["ebf"] if rg else None

        # ---- EBF row ----
        if tx_ebf:
            if rx_ebf:
                err, bits, lenmis = bit_errors_hex(tx_ebf.payload_hex, rx_ebf.payload_hex)
                merged_rows.append({
                    "tx_group_id": tg["group_id"],
                    "tx_order_in_group": 0,
                    "frame_type": "EBF",
                    "hdr6": tx_ebf.hdr6,
                    "tx_time": tx_ebf.time_str or "",
                    "tx_time_inferred": 0,
                    "rx_time": rx_ebf.time_str or "",
                    "tx_payload_hex": tx_ebf.payload_hex,
                    "rx_payload_hex": rx_ebf.payload_hex,
                    "rx_rssi": rx_ebf.rssi if rx_ebf.rssi is not None else "",
                    "rx_snr": rx_ebf.snr if rx_ebf.snr is not None else "",
                    "rx_crc": rx_ebf.crc or "",
                    "bit_errors_total": err,
                    "compare_bits": bits,
                    "length_mismatch_bits": lenmis,
                    "ber_total": (err / bits) if bits else "",
                    "match_status": "matched",
                })
            else:
                merged_rows.append({
                    "tx_group_id": tg["group_id"],
                    "tx_order_in_group": 0,
                    "frame_type": "EBF",
                    "hdr6": tx_ebf.hdr6,
                    "tx_time": tx_ebf.time_str or "",
                    "tx_time_inferred": 0,
                    "rx_time": "",
                    "tx_payload_hex": tx_ebf.payload_hex,
                    "rx_payload_hex": "",
                    "rx_rssi": "",
                    "rx_snr": "",
                    "rx_crc": "",
                    "bit_errors_total": "",
                    "compare_bits": "",
                    "length_mismatch_bits": "",
                    "ber_total": "",
                    "match_status": "missing_rx",
                })

        # ---- EBA rows ----
        tx_ebas: List[Frame] = tg["ebas"]
        rx_ebas: List[Frame] = rg["ebas"] if rg else []
        mapping = match_eba_list(tx_ebas, rx_ebas) if rx_ebas else [None] * len(tx_ebas)

        inferred_tx_time = tx_ebf.time_str if tx_ebf else ""

        for k, txf in enumerate(tx_ebas, start=1):
            rxj = mapping[k - 1]
            rxf = rx_ebas[rxj] if (rxj is not None) else None

            if rxf:
                err, bits, lenmis = bit_errors_hex(txf.payload_hex, rxf.payload_hex)
                merged_rows.append({
                    "tx_group_id": tg["group_id"],
                    "tx_order_in_group": k,
                    "frame_type": "EBA",
                    "hdr6": txf.hdr6,
                    "tx_time": inferred_tx_time,
                    "tx_time_inferred": 1,
                    "rx_time": rxf.time_str or "",
                    "tx_payload_hex": txf.payload_hex,
                    "rx_payload_hex": rxf.payload_hex,
                    "rx_rssi": rxf.rssi if rxf.rssi is not None else "",
                    "rx_snr": rxf.snr if rxf.snr is not None else "",
                    "rx_crc": rxf.crc or "",
                    "bit_errors_total": err,
                    "compare_bits": bits,
                    "length_mismatch_bits": lenmis,
                    "ber_total": (err / bits) if bits else "",
                    "match_status": "matched",
                })

                # field-level BER for EBA
                tx_fields = split_eba_fields(txf.payload_hex, n_devices=args.n_dev)
                rx_fields = split_eba_fields(rxf.payload_hex, n_devices=args.n_dev)
                if tx_fields and rx_fields and len(tx_fields) == len(rx_fields):
                    for (field, dev_i, tx_hex), (_, _, rx_hex) in zip(tx_fields, rx_fields):
                        ferr, fbits, flenmis = bit_errors_hex(tx_hex, rx_hex)
                        eba_rows.append({
                            "tx_group_id": tg["group_id"],
                            "tx_order_in_group": k,
                            "hdr6": txf.hdr6,
                            "tx_time": inferred_tx_time,
                            "rx_time": rxf.time_str or "",
                            "field": field,
                            "device_index": dev_i if dev_i is not None else "",
                            "tx_hex": tx_hex,
                            "rx_hex": rx_hex,
                            "bit_errors": ferr,
                            "compare_bits": fbits,
                            "length_mismatch_bits": flenmis,
                            "ber": (ferr / fbits) if fbits else "",
                            "rx_crc": rxf.crc or "",
                            "rx_rssi": rxf.rssi if rxf.rssi is not None else "",
                            "rx_snr": rxf.snr if rxf.snr is not None else "",
                        })
            else:
                merged_rows.append({
                    "tx_group_id": tg["group_id"],
                    "tx_order_in_group": k,
                    "frame_type": "EBA",
                    "hdr6": txf.hdr6,
                    "tx_time": inferred_tx_time,
                    "tx_time_inferred": 1,
                    "rx_time": "",
                    "tx_payload_hex": txf.payload_hex,
                    "rx_payload_hex": "",
                    "rx_rssi": "",
                    "rx_snr": "",
                    "rx_crc": "",
                    "bit_errors_total": "",
                    "compare_bits": "",
                    "length_mismatch_bits": "",
                    "ber_total": "",
                    "match_status": "missing_rx",
                })

    tx_stem = args.tx.stem
    rx_stem = args.rx.stem
    out1 = args.outdir / f"merged_frames_{tx_stem}__{rx_stem}.csv"
    out2 = args.outdir / f"eba_fields_ber_{tx_stem}__{rx_stem}.csv"

    merged_fields = [
        "tx_group_id", "tx_order_in_group", "frame_type", "hdr6",
        "tx_time", "tx_time_inferred", "rx_time",
        "tx_payload_hex", "rx_payload_hex",
        "rx_rssi", "rx_snr", "rx_crc",
        "bit_errors_total", "compare_bits", "length_mismatch_bits", "ber_total",
        "match_status",
    ]
    eba_fields = [
        "tx_group_id", "tx_order_in_group", "hdr6",
        "tx_time", "rx_time",
        "field", "device_index",
        "tx_hex", "rx_hex",
        "bit_errors", "compare_bits", "length_mismatch_bits", "ber",
        "rx_crc", "rx_rssi", "rx_snr",
    ]

    write_csv(out1, merged_rows, merged_fields)
    write_csv(out2, eba_rows, eba_fields)

    print(f"OK: wrote {len(merged_rows)} rows -> {out1}")
    print(f"OK: wrote {len(eba_rows)} rows -> {out2}")


if __name__ == "__main__":
    main()
